
# This is a header block example for lab 1.
#
# You will need to supply the following information.
#
# Name: Alex Zaharia
# Instructor: Clark Turner
# Section: CPE-101-02-2208
#

for i in range(1,6):
	print (i)


counter = 0
while counter < 5:
	print ("Alex")
	counter += 1
