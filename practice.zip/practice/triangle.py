count = 0
total = 20
while count <= total:
	count = count + 2
	print (" " * int((total-count)/2), "x" * count)
