#Lab4
#Alex Zaharia
# Clark Turner

import driver

def letter(row, col):
	count = 0
	for y in range(row):
		for x in range(col):
			if x == count or x == col - count - 1:
				print ("X", end = "")
			else:
				print("O", end = "") 
		print()
		count = count + 1
	
letter(7, 7)

if __name__ == '__main__':
	driver.comparePatterns(letter)
