#Lab4
#Alex Zaharia
# Clark Turner

import driver

def letter(row, col):
	for y in range(row):
		for x in range(col):
			if y == 2 and x >= 4 and x <= 9 or y == 3 and x >= 4 and x <= 9 or y == 4 and x >= 4 and x <= 6 or y == 5 and x >= 4 and x <= 6:
				print("Z", end = "")
			elif y == 4 and x >= 7 and x <= 9 or y == 5 and x >= 7 and x <= 9:
				print("X", end = "")
			elif y == 4 and x >= 10 and x <= 12 or y == 5 and x >= 10 and x <= 12 or y == 6 and x >= 7 and x <= 12:
				print("B", end = "")
			else:
				print("T", end = "")
		print()
	
letter(10, 20)

if __name__ == '__main__':
	driver.comparePatterns(letter)
