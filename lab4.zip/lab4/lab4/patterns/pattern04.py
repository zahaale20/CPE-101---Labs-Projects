#Lab4
#Alex Zaharia
# Clark Turner

import driver

def letter(row, col):
	for y in range(row):
		for x in range(col):
			if y >= 2 and y <= 4 and x >= 3 and x <= 6:
				print("M", end = "")
			else:
				print("S", end = "")
		print()
	
letter(7, 10)

if __name__ == '__main__':
	driver.comparePatterns(letter)
