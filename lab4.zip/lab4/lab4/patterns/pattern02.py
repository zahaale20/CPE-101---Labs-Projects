#Lab 4
#Alex Zaharia
#Clark Turner

import driver

def letter(row, col):
	for y in range(row):
		for x in range(col):
			if y <= 10:
				print("R", end = "")
			else:
				print("Q", end = "")
		print()
	
letter(20, 20)


if __name__ == '__main__':
	driver.comparePatterns(letter)
