#Project 3
#Alex Zaharia
#Clark Turner

cage_sum = 0
number_of_cells = 0
puzzle = []
cages = []
cage = []
size_of_puzzle = 0
number_of_cages = 0

def get_cages():
	return cages

def check_rows_valid():
	for row in puzzle:
		for col in range(0, len(row)):
			for element in range(0, len(row)):
				if row[col] == row[element] and col != element:
					return False
	return True

def check_columns_valid():
	count1 = -1
	for row in puzzle:
		count1 += 1
		count2 = -1
		for row1 in puzzle:
			count1 += 1
			for col in range(0, len(row1)):
				if row[col] == row1[col] and count1 != count2:
					return False
	return True


def check_cages_valid():
	for cage_info in cages:
		cageSum1 = cage_info[0]
		puzzleSum = 0
		for cell in cage_info[1]:
			row = cell // len(puzzle)
			col = cell % len(puzzle)
			puzzleSum += puzzle[row][col]
		if puzzleSum != cageSum1:
			return False
	return True


def check_valid(checks):
	if check_rows_valid() and check_columns_valid() and check_cages_valid():
		checks += 3
		return True
	checks += 3
	return False

def createCagesAndPuzzle():
	size_of_puzzle = int(input("Enter size of puzzle(one value):"))
	number_of_cages = int(input("Enter number of cages in puzzle:"))
	for i in range(0, number_of_cages):
		cage_sum = int(input("Enter cage sum:"))
		number_of_cells = int(input("Enter number of cells in cage:"))
		cells_of_cage = []
		for i in range(0, number_of_cells):	
			cell_value = int(input("Enter cell:"))
			cells_of_cage.append(cell_value)	
		print("")
		cages.append([cage_sum, cells_of_cage])		
	print ("Cages:\n", cages)
	for row in range(0, size_of_puzzle):
		temp_row = []
		for col in range(0, size_of_puzzle):
			temp_row.append(0)
		puzzle.append(temp_row)
	print("Puzzle:\n", puzzle)

def solvePuzzle():
	checks = 0
	backtracks = 0
	tf = False

	while not tf:
		for row in range(0, len(puzzle)):
			for col in range(0, len(puzzle[row])):
				for cage_info in cages:
					cageSum = cage_info[0]				
					for cell in cage_info[1]:
						if puzzle[row][col] >= cageSum:
							puzzle[row][col] = 0
							col -= 1
							if col <= 0:
								col = len(puzzle[row]) - 1
								row -= 1
							backtracks += 1
						elif not check_valid(checks):	
							puzzle[row][col] += 1
							if check_valid(checks):
								tf = True
						elif check_valid(checks):
							tf = True
	
	print("--SOLUTION--")
	for row in puzzle:
		print (row)
	print ("Checks: ", checks)
	print("Backtracks: ", backtracks)

createCagesAndPuzzle()
solvePuzzle()	
