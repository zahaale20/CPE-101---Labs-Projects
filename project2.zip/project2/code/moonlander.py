from landerFuncs import *

def main():
	showWelcome()

	altitude = getAltitude()
	fuelAmount = getFuel()
	elapsedTime = 0
	fuelRate = 0
	velocity = 0
	gravity = -1.62

	displayLMState(elapsedTime, altitude, velocity, fuelAmount, fuelRate)

	while fuelAmount >= 0 or altitude <= 0:
		elapsedTime = elapsedTime + 1
		fuelRate = getFuelRate(fuelAmount)
		acceleration = updateAcceleration(gravity, fuelRate)
		velocity = updateVelocity(velocity, acceleration)
		altitude = updateAltitude(altitude, velocity, acceleration)
		fuelAmount = updateFuel(fuelAmount, fuelRate)
		displayLMState(elapsedTime, altitude, velocity, fuelAmount, fuelRate)
	
	if fuelAmount >= 0:
		print("OUT OF FUEL - Elapsed Time:", elapsedTime, "Altitude:", altitude, "Velocity:", velocity)
	displayLLMLandingStatus(velocity)
		
		

if __name__ == '__main__':
	main()
