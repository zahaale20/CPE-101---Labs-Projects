#Project 2, Function Tests
#Name: Alex Zaharia
#Professor: Clark Turner

import unittest
from landerFuncs import *

class TestCases(unittest.TestCase):
	def test_update_acc1(self):
		self.assertAlmostEqual(updateAcceleration(1.62, 0), -1.62)
	def test_update_acc2(self):
		self.assertAlmostEqual(updateAcceleration(1.62, 5), 0)
	def test_update_vel1(self):
		self.assertAlmostEqual(updateVelocity(0, -1.62), -1.62)
	def test_update_vel2(self):
		self.assertAlmostEqual(updateVelocity(-10, -1.62), -11.62)
	def test_update_alt1(self):
		self.assertAlmostEqual(updateAltitude(1000, -10, -15), 982.5)
	def test_update_alt2(self):
		self.assertAlmostEqual(updateAltitude(100, -6, -10), 89.0)
	def test_update_fuel1(self):
		self.assertAlmostEqual(updateFuel(100, 5), 95)
	def test_update_fuel1(self):
		self.assertAlmostEqual(updateFuel(85, 1), 84)
      

# Run the unit tests.
if __name__ == '__main__':
	unittest.main()

