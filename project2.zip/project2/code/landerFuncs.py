# Project 2 - Moonlander
# Author: Alex Zaharia	
# Professor: Clark Turner:

def showWelcome():
	print("Welcome abroad the Lunar Module Flight Simulator\n\n\tTo begin you must specify the LM's initial altitude\n\tand fuel level. To simulate the actual LM use\n\tvalues of 1300 meters and 500 liters, respectively.\n\n\tGood luck and may the force be with you!\n")
   
def getFuel():
	fuel = int(input("Enter the initial amount of fuel on board the LM (in liters)"))
	if fuel <= 0:
		print("ERROR: Fuel must be positive, please try again")
		getFuel()
	return fuel

def getAltitude():
	altitude = float(input("Enter the initial altitude of the LM (in meters)"))
	if altitude <= 0 and altitude > 9999:
		print("ERROR: Altitude must be between 1 and 9999, inclusive, please try again")
		getAltitude()
	return altitude
		
   
def displayLMState(elapsedTime, altitude, velocity, fuelAmount, fuelRate):
	print("LM state at retrorocket cutoff", "\n\tElapsed Time:", elapsedTime, "s\n\tFuel:", fuelAmount,"l\n\tRate:", fuelRate,"l/s\n\tAltitude:", altitude, "m\n\tVelocity:", velocity, "m/s")

def getFuelRate(currentFuel):
	fuelRate = int(input("Enter fuel rate (0-9, 0-freefall, 5=constant velocity, 9=max thrust)"))
	if fuelRate < 0 or fuelRate > 9:
		print("ERROR: Fuel Rate must be between 0 and 9, inclusive, please try again")
		getFuelRate(currentFuel)
	else:
		if currentFuel < fuelRate:
			return currentFuel
		else:
			return fuelRate

def updateAcceleration(gravity, fuelRate):
	return gravity * ((fuelRate / 5) -1)
	
def updateAltitude(altitude, velocity, acceleration):
	return altitude + velocity + (acceleration / 2)

def updateVelocity(velocity, acceleration):
	return velocity + acceleration

def updateFuel(fuel, fuelRate):
	return fuel - fuelRate

def displayLMLandingStatus(velocity):
	if velocity <= 0 and velocity >= -1:
		print("Status at landing - The eagle has landed!")
	elif velocity < -1 and velocity > -10:
		print("Status at landing - Enjoy the oxygen while it lasts!")
	elif velocity <= -10:
		print("Status at landing - Ouch - that hurt!")
