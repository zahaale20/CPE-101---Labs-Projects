#Project 4
#Alex Zaharia
#Clark Turner

from funcs import *

def searchPuzzle(puzzleInput):
	if puzzleInput == "puzzle0":
		data = open("/home/azaharia/cpe101/project4/puzzle0")
	elif puzzleInput == "puzzle1":
		data = open("/home/azaharia/cpe101/project4/puzzle1")
	elif puzzleInput == "puzzle2":
		data = open("/home/azaharia/cpe101/project4/puzzle2")
	foundWords = []
#Create Puzzle List
	puzzle = []
	tempList = []
	letters = data.readline()
	for char in letters:
		if len(tempList) >= 10:
			puzzle.append(tempList)
			tempList = []
		tempList.append(char)
#Create Word List
	inputWords = data.readline().split(" ")
	tempList = []
	words = []
	completeWords = []
	for word in inputWords:
		completeWords.append(word)
		for char in word:
			tempList.append(char)
		words.append(tempList)
		tempList = []
	#Print puzzle and word list
	print("--Puzzle--")
	for row in puzzle:
		for char in row:
			print(char, end = " ")
		print()
	print("\n--Words--")
	for word in words:
		string = ""
		for char in word:
			string += str(char)
		print(string)
	print()

	foundWords = []
	wordsNotFound = []
	tempList = []

	tempList = searchForward(foundWords, words, puzzle)
	foundWords = searchBackward(tempList, words, puzzle)
	tempList = searchDown(foundWords, words, puzzle)
	foundWords = searchUp(tempList, words, puzzle)
	tempList = searchDiagonal(foundWords, words, puzzle)
	foundWords = tempList
	wordsNotFound = notFound(completeWords, foundWords)
	for info in range(0, len(foundWords)):
		print(foundWords[info][0], ": (", foundWords[info][1], ") row:", foundWords[info][2], "col:", foundWords[info][3])
	for word in wordsNotFound:
		print(word, ": word not found")
