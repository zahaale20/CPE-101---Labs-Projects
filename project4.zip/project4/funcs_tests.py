#Project 4
#Alex Zaharia
#Clark Turner
from word_finder import *

def test1():
	print("Output0 file is printed below. Compare it to my puzzle0 output below.\n")
	output = open("/home/azaharia/cpe101/project4/output0") 
	count = 0
	for row in output:
		print(row, end = "")
	print("\n\nThis is my puzzle0 output below\n")
	searchPuzzle("puzzle0")

def test2():
	print("\nOutput1 file is printed below. Compare it to my puzzle1 output below.\n")
	output = open("/home/azaharia/cpe101/project4/output1")
	count = 0
	for row in output:
		print(row, end = "")
	print("\n\nThis is my puzzle1 output below\n")
	searchPuzzle("puzzle1")

def test3():
	print("\nOutput2 file is printed below. Compare it to my puzzle2 output below.\n")
	output = open("/home/azaharia/cpe101/project4/output2")
	count = 0
	for row in output:
		print(row, end = "")
	print("\n\nThis is my puzzle2 output below\n")
	searchPuzzle("puzzle2")

test1()
test2()
test3()
