#Projet 4
#Alex Zaharia
#Clark Turner

def searchForward(foundWords, words, puzzle):
	for word in words:
		for row in range(0, len(puzzle)):
			for col in range(0, len(puzzle[row])):
				count = 0
				for char in range(0, len(word)):
					if len(puzzle[row]) - col >= len(word) and puzzle[row][col + char] == word[char]:	 
						count += 1	
				if count == len(word):
					string = ""
					for char in word:
					 	string += str(char)
					foundWords.append([string, "FORWARD", row, col])	
	return foundWords

def searchBackward(foundWords, words, puzzle):
	for word in words:
		for row in range(0, len(puzzle)):
			for col in range(len(puzzle) - 1, -1, -1):
				count = 0
				for char in range(0, len(word)):
					if col >= len(word) and puzzle[row][col - char] == word[char]:
						count += 1
				if count == len(word):
					string = ""
					for char in word:
						string += str(char)
					foundWords.append([string, "BACKWARD", row, col])
	return foundWords

def searchDown(foundWords, words, puzzle):
	for word in words:
		for col in range(0, len(puzzle)):
			for row in range(0, len(puzzle[col])):
				count = 0
				for char in range(0, len(word)):
					if len(puzzle) - row >= len(word) and puzzle[row + char][col] == word[char]:
						count += 1
				if count == len(word):
					string = ""
					for char in word:
						string += str(char)
					foundWords.append([string, "DOWN", row, col])
	return foundWords

def searchUp(foundWords, words, puzzle):
	for word in words:
		for col in range(0, len(puzzle)):
			for row in range(len(puzzle[col]) - 1, -1, -1):				
				count = 0
				for char in range(0, len(word)):
					if col >= len(word) and puzzle[row - char][col] == word[char]:
						count += 1	
				if count == len(word):
					string = ""
					for char in word:
						string += str(char)
					foundWords.append([string, "UP", row, col])
	return foundWords

def searchDiagonal(foundWords, words, puzzle):
	for word in words:
		for row in range(0, len(puzzle) - len(word)):
			for col in range(0, len(puzzle[row]) - len(word)):
				count = 0
				for char in range(0, len(word)):
					if len(puzzle) >= len(word) and len(puzzle[row]) >= len(word) and puzzle[row + char][col + char] == word[char]:
						count += 1
				if count == len(word):
					string = ""
					for char in word:
						string += str(char)
					foundWords.append([string, "DIAGONAL", row, col])
	return foundWords

def notFound(completeWords, foundWords):	
	temp = []
	wordsNotFound = []
	for info in range(0, len(foundWords)):
		temp.append(foundWords[info][0])
	for word in completeWords:
		if word not in temp:
			wordsNotFound.append(word)
	return wordsNotFound
