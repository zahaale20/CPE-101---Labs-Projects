import unittest
from strspn import *

class TestStrSpn(unittest.TestCase):
        def test_strspn(self):
                self.assertEqual(my_strspn("minute", "simulation"), 5)


if __name__ == '__main__':
        unittest.main()
