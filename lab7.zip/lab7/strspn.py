def my_strspn(str1, str2):
	num = 0
	str2 = "".join(set(str2)) 
	print(str1, str2)
	for char1 in str1:
		for char2 in str2:
			if char2 == char1:				
				num += 1					
	return num

#word1 = input("Enter first word:")
#word2 = input("Enter second word:")
#print(my_strspn(word1, word2))
		
