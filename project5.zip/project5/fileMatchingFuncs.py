#Project 5
#Alex Zaharia
#Clark Turner

class Entry:
	def __init__(self, account_num, name, balance, phone, city):
		self.account_num = account_num
		self.name = name
		self.balance = balance
		self.phone = phone
		self.city = city

	def __eq__(self, entry):
		if self.account_num == entry.account_num and self.name == entry.name and self.balance == entry.balance and self.phone == entry.phone and self.city == entry.city:
			return True
		else:
			return False

def read_file(file_name):
	list_entries = []
	if file_name == "oldMaster.dat":
		data = open("/home/azaharia/cpe101/project5/oldMaster.dat")
	if file_name == "transaction.dat":
		data = open("/home/azaharia/cpe101/project5/transaction.dat")
	for entry in data:
		list_entries.append(entry.split())
	if file_name == "oldMaster.dat":
		print("--Old Master--")
		for entry in range(0, len(list_entries)):
			string = ""
			for detail in range(0, len(list_entries[entry])):
				string += (str(list_entries[entry][detail]) + "\t")			
			print(string)
		print()
	return list_entries

def update_list(entries, transactions): 	
	for transaction in range(0, len(transactions)):
		for entry in range(0, len(entries)):
			if transactions[transaction][0] == entries[entry][0]:
				entries[entry][3] = str(round(float(entries[entry][3]) + float(transactions[transaction][1]), 2))
	return entries

def write_and_print_file(list_entries, output_file):
	str_entries = []
	if output_file == "newMaster.dat":
		print("\n--New Master--")
		new_file = open("/home/azaharia/cpe101/project5/newMaster.dat", "w+")
	elif output_file == "sorted_newMaster.dat":
		print("\n--New Sorted Master--")
		new_file = open("/home/azaharia/cpe101/project5/sorted_newMaster.dat", "w+")
	for entry in range(0, len(list_entries)):
		string = ""
		for detail in range(0, len(list_entries[entry])):
			string += (str(list_entries[entry][detail]) + "\t")
		new_file.write(string)
		print(string)
	print()
	return new_file

def sort_list(list_entries):
	account_numbers = []
	for entry in range(0, len(list_entries)):
		account_numbers.append(list_entries[entry][4])
	sorted_list = [list_entries for entry,list_entries in sorted(zip(account_numbers, list_entries))]
	return sorted_list 

entries = read_file("oldMaster.dat")
transactions = read_file("transaction.dat")
list_entries = update_list(entries, transactions)
new_file = write_and_print_file(list_entries, "newMaster.dat")
list_entries = sort_list(list_entries)
new_file = write_and_print_file(list_entries, "sorted_newMaster.dat")


