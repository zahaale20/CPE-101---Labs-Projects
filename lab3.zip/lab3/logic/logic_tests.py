#Lab3, logic_tests.py
#Name: Alex Zaharia
#Professor: Clark Turner

import unittest
from logic import *

class TestCases(unittest.TestCase):
	def test_function_names(self):
		is_even(0)
		is_even(5)
		is_even(6)
		in_an_interval(0)
		in_an_interval(1)
		in_an_interval(2)
		in_an_interval(5)
		in_an_interval(9)
		in_an_interval(47)
		in_an_interval(50)
		in_an_interval(92)
		in_an_interval(12)
		in_an_interval(16)
		in_an_interval(19)
		in_an_interval(20)
		in_an_interval(100)
		in_an_interval(101)
		in_an_interval(102)
		in_an_interval(103)
		in_an_interval(104)

# Run the unit tests.
if __name__ == '__main__':
	unittest.main()

