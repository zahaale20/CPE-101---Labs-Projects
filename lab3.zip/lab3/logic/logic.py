#Lab 3, logic.py
#Name: Alex Zaharia
#Professor: Clark Turner

def is_even(num):
	return num % 2

def in_an_interval(num):
	return num >= 2 and num < 9 or num > 47 and num <92 or num > 12 and num <= 19 or num >= 101 and num <= 103

	
