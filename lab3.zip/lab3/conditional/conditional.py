#Lab 3, Conditional.py
#Name: Alex Zaharia
#Professor: Clark Turner

def max_101(num1, num2):
	if num1 > num2:
		return num1
	else:
		return num2

def max_of_three(num1, num2, num3):
	if num1 > num2 and num1 > num3:
		return num1
	elif num2 > num3:
		return num2
	else:
		return num3
	#return max_101(max_101(num1, num2), num3)
	
def rental_late_fee(days):
	if days <= 0:
		return 0
	elif days <= 9:
		return 5
	elif days <= 15:
		return 7
	elif days <= 24:
		return 19
	else:
		return 100
