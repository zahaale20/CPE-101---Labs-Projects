#Lab3, conditional_tests.py
#Name: Alex Zaharia
#Professor: Clark Turner

import unittest
from conditional import *

class TestCases(unittest.TestCase):
	def test_function_names(self):
		max_101(0, 0)
		max_101(30, 70)
		max_101(100, 50)
		max_of_three(0, 0, 0)
		max_of_three(4, 7, 9)
		max_of_three(6, 9, 5)
		max_of_three(10, 3, 7)
		rental_late_fee(0)
		rental_late_fee(5)
		rental_late_fee(10)
		rental_late_fee(20)
		rental_late_fee(30)

# Run the unit tests.
if __name__ == '__main__':
	unittest.main()

