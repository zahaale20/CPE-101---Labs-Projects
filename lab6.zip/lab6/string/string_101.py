#Lab 6
#Alex Zaharia
#Clark Turner

def str_rot_13(string):
	string1 = ""
	for letter in string:
		if ord(letter) < 65 or ord(letter) > 122:
			string1 += letter
		elif ord(letter) + 13 > 122:
			string1 += str(ord(letter) - 13)
		else:
			string1 += str(ord(letter) + 13)
	return string1

def str_translate_101(string, c1, c2):
	string1 = ""
	for letter in string:
		if letter == c1:
			string1 += str(c2)
		else:
			string1+= str(letter)
	return (string1)


