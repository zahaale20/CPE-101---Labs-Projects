import unittest
from char import *

class TestChar(unittest.TestCase):
	def test_lower(self):
		self.assertEqual(is_lower_101('d'), True)
	def test_lower1(self):
		self.assertEqual(is_lower_101('C'), False)
	def test_rot13_1(self):
		self.assertEqual(char_rot_13('a'), 113)
	def test_rot13_2(self):
		self.assertEqual(char_rot_13('D'), 68)
if __name__ == '__main__':
	unittest.main()

