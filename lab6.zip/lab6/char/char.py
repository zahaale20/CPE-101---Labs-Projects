def is_lower_101(char):
	return ord(char) in range(97,123)

def char_rot_13(char):
	num = ord(char)
	if num < 65 and num > 122:
		return num
	else:
		if num + 13 > 122:
			num -= 13
		else:
			num += 13
