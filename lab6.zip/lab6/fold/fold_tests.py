import unittest
from fold import *

class TestCases(unittest.TestCase):
	def test_1(self):
		list1 = [1, 2, 3, 4]
		self.assertEqual(sum(list1), 10)
	def test_2(self):
		list1 = [10, 15, 35]
		self.assertEqual(sum(list1), 60)
	def test_3(self):
		list1 = [1, 2, 3, 4]
		self.assertEqual(index_of_smallest(list1), 0)
	def test_4(self):
		list1 = [1, 2, -3, 4]
		self.assertEqual(index_of_smallest(list1), 2)

# Run the unit tests.
if __name__ == '__main__':
	unittest.main()

