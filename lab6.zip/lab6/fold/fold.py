#Lab 6
#Alex Zaharia
#Clark Turner

def sum (list1):
	total = 0
	for num in list1:
		total += num	
	return total

def index_of_smallest(list1):
	smallest = 0
	if len(list1) == 0:
		return -1
	else:
		for num in list1:
			if list1[smallest] > num:
				smallest = list1.index(num)
	return smallest


		
