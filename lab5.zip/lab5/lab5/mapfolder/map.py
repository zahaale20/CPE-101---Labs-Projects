#Lab5
#Alex Zaharia
#Clark Turner
import math

def square_all(list1):
	list2 = [num ** 2 for num in list1]
	return list2

def add_n_all(list1, n):
	for num in range(len(list1)):
		list1[num] = n + list1[num]
	return list1

def distance_all(list1):
	list2 = []
	templist = []
	while list1:
		templist = list1.pop(0)
		distance = math.sqrt((templist[1] ** 2) +  (templist[0] ** 2))
		list2.append(distance)
	return(list2)
			

