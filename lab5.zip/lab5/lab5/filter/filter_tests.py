import unittest
from filter import *
import point

class TestCases(unittest.TestCase):
	def test_1(self):
		list1 = [-1, 5, 6, -4, 10]
		self.assertEqual(are_positive(list1), [5, 6, 10])
	def test_2(self):
		list1 = [-6, 7, 8, -2, 105]
		self.assertEqual(are_positive(list1), [7, 8, 105])
	def test_3(self):
		list1 = [-1, 5, 6, -4, 10]
		self.assertEqual(are_greater_than(list1, 0), [5, 6, 10])
	def test_4(self):
		list1 = [-6, 7, 8, -2, 105]
		self.assertEqual(are_greater_than(list1, 6), [7, 8, 105])
	def test_5(self):
		list1 = []
		list1.append([1, 2])
		list1.append([1, -2])
		list1.append([-1, 2])
		list1.append([-1, -2])
		self.assertEqual(are_in_first_quadrant(list1), ["Yes", "No", "No", "No"])

# Run the unit tests.
if __name__ == '__main__':
	unittest.main()

