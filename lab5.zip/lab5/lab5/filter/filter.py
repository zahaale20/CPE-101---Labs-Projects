#Lab5
#Alex Zaharia
#Clark Turner

def are_positive(list1):
	list2 = []
	while list1:
		num = list1.pop(0)
		if num > 0:
			list2.append(num)
	return list2

def are_greater_than(list1, n):
	list2 = []
	for num in list1:
		if num > n:
			list2.append(num)
	return list2

def are_in_first_quadrant(list1):
	list2 = []
	list2 = ["Yes" if num.pop(0) > 0 and num.pop(0) > 0 else "No" for num in list1]
	return list2		
