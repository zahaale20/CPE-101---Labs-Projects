# Project 1, skater.py
# Name: Alex Zaharia
# Instructor: Clark Turner

import sys
from funcs import functions

newFunctions = functions

def quit(input1):
	if input1 == 'quit':
		quit2 = input("Are you sure you want to quit the program? (yes/no)")
		if quit2 == "yes":
			sys.exit("You quit the program. :(")	

def main():
	print("\nWelcome to Alex's Skater Project.\nType 'quit' at anytime to terminate the program.\n")

	weight = input("How much does skater 1 weigh? (in pounds)")
	quit(weight)
	print("Skater 1's weight is", weight, "pounds.\n")
	weight = float(weight)

	distance = input("How far away is skater 2? (in meters)")
	quit(distance)
	print("The distance is", distance, "meters.\n")
	distance = float(distance)

	object1 = input("Will you throw a (t)omato, (p)banana cream pie, (r)ock, (l)ight saber, or (g)lawn gnome?")
	quit(object1)
	massObject = float(newFunctions.getMassObject(object1))
	print("Object weight:", massObject, "\n")
	if massObject <= 0.1:
		print("You're going to get an F!")
	elif massObject > 0.1 and massObject <= 1.0:
		print("Make sure your professor is OK.")
	elif massObject > 1.0:
		if distance < 20.0:
			print("How far away is the hospital?")
		elif distance >= 20.0:
			print("RIP Professor.")

	massSkater = float(newFunctions.poundsToKG(weight))
	print ("\nSkater 1 Weight:", massSkater)

	velocityObject = float(newFunctions.getVelocityObject(distance))
	print ("Object Velocity:", velocityObject)

	velocitySkater = newFunctions.getVelocitySkater(massSkater, massObject, velocityObject)
	print("Skater 1's Velocity:", velocitySkater, "\n")
	if velocitySkater < 0.2:
		print("My grandmother skaters faster than you!")
	elif velocitySkater >= 1.0:
		print("Look out for that railing!!!")	

if __name__ == '__main__':
	main()
