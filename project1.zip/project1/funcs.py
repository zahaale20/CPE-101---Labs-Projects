#Project 1, funcs.py
#Name: Alex Zaharia
#Professor: Clark Turner

import math
class functions:
	def poundsToKG(pounds):
		return pounds * 0.453592
	def getMassObject(object1):
		if object1 == 't':
			return 0.1
		elif object1 == 'p':
			return 1.0
		elif object1 == 'r':
			return 3.0
		elif object1 == 'l':
			return 5.3
		elif object1 == 'g':
			return 5.3
		else:
			return 0.0
	def getVelocityObject(distance):
		gravity = 9.8
		return (math.sqrt(gravity * distance / 2.0))

	def getVelocitySkater(massSkater, massObject, velocityObject):
		return (massObject * velocityObject / massSkater)
		

