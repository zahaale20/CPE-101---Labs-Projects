#Project 1, funcs_tests.py
#Name: Alex Zaharia
#Professor: Clark Turner

import unittest
from funcs import functions

f = functions

class TestCases(unittest.TestCase):
	def test_poundsToKG_1(self):
		self.assertAlmostEqual(f.poundsToKG(0), 0.0)
	def test_poundsToKG_3(self):
		self.assertAlmostEqual(f.poundsToKG(200), 90.7184)
	def test_poundsToKG_2(self):
		self.assertAlmostEqual(f.poundsToKG(75), 34.0194) 
	def test_getMassObject_1(self):
		self.assertEqual(f.getMassObject('t'), 0.1)
	def test_getMassObject_2(self):
		self.assertEqual(f.getMassObject('p'), 1.0)
	def test_getMassObject_3(self):
		self.assertEqual(f.getMassObject('r'), 3.0)
	def test_getVelocityObject_1(self):
		self.assertAlmostEqual(f.getVelocityObject(0), 0.0)
	def test_getVelocityObject_2(self):
		self.assertAlmostEqual(f.getVelocityObject(60), 17.146428199482248)
	def test_getVelocityObject_3(self):
		self.assertAlmostEqual(f.getVelocityObject(100), 22.135943621178658)
	def test_getVelocitySkater_1(self):
		self.assertAlmostEqual(f.getVelocitySkater(100, 0, 100), 0.0)
	def test_getVelocitySkater_2(self):
		self.assertAlmostEqual(f.getVelocitySkater(75, 0.1, 17.146428199482248), 0.02286190426597633)
	def test_getVelocitySkater_3(self):
		self.assertAlmostEqual(f.getVelocitySkater(100, 0.1, 22.135943621178658), 0.02213594362117866)
	def test_getVelocitySkater_4(self):
		self.assertAlmostEqual(f.getVelocitySkater(75, 1.0, 17.146428199482248), 0.2286190426597633)
	def test_getVelocitySkater_5(self):
		self.assertAlmostEqual(f.getVelocitySkater(100, 1.0, 22.135943621178658), 0.22135943621178658) 
	def test_getVelocitySkater_6(self):
		self.assertAlmostEqual(f.getVelocitySkater(75, 3.0, 17.146428199482248), 0.68585712797929)
	def test_getVelocitySkater_7(self):
		self.assertAlmostEqual(f.getVelocitySkater(100, 3.0, 22.135943621178658), 0.6640783086353598)
	def test_getVelocitySkater_8(self):
		self.assertAlmostEqual(f.getVelocitySkater(75, 5.3, 17.146428199482248), 1.2116809260967454)
	def test_getVelocitySkater_9(self):
		self.assertAlmostEqual(f.getVelocitySkater(100, 5.3, 22.135943621178658), 1.1732050119224688)
	def test_getVelocitySkater_10(self):
		self.assertAlmostEqual(f.getVelocitySkater(75, 9.07, 17.146428199482248), 2.0735747169240533)
	def test_getVelocitySkater_11(self):
		self.assertAlmostEqual(f.getVelocitySkater(100, 9.07, 22.135943621178658), 2.0077300864409042)

if __name__ == '__main__':
	unittest.main()
