#Lab 2
#Name: Alex Zaharia
#Professor: Clark Turner

import math

class functions:
	def f(x):
		return 7 * x ** 2 + 2 * x

	def g(x, y):
		return (x ** 2 + y ** 2) / (3 * x)

	def hypotenuse(length, width):
		return math.sqrt(length ** 2 + width ** 2)
	
	def is_positive(num):
		return num > 0
