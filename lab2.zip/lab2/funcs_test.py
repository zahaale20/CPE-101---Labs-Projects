#Lab 2
#Name: Alex Zaharia
#Professor: Clark Turner

import unittest
from funcs import functions

func = functions

class TestCases(unittest.TestCase):
	def test_f_1(self): 
		self.assertEqual(func.f(10), 720)
	def test_f_2(self):
		self.assertEqual(func.f(1), 9)
	def test_g_1(self):
		self.assertAlmostEqual(func.g(2,3), 2.1666666666)
	def test_g_2(self):
		self.assertAlmostEqual(func.g(3,4), 2.7777777777)
	def test_hypotenuse_1(self):
		self.assertEqual(func.hypotenuse(3,4), 5)
	def test_hypotenuse_2(self):
		self.assertEqual(func.hypotenuse(5, 12), 13)
	def test_is_positive_1(self):
		self.assertEqual(func.is_positive(5), True)
	def test_is_positive_2(self):
		self.assertEqual(func.is_positive(-5), False)

if __name__ == '__main__':
        unittest.main()
