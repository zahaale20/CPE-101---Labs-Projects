#Lab 2
#Name: Alex Zaharia
#Professor: Clark Turner

def calculateMars(weight):
	return weight * 0.38

def calculateJupiter(weight):
	return weight * 2.34

weightEarth = int(input("What is your weight? (in pounds)"))

print("\nWeight on Earth:", weightEarth, "pounds.\nWeight on Mars:", calculateMars(weightEarth),"pounds.\nWeight on Jupiter:", calculateJupiter(weightEarth),"pounds.")
